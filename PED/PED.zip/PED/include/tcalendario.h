//adam roy frederick william, reading y2483358q
#ifndef _TCALENDARIO_
#define _TCALENDARIO_
#include <iostream>
using namespace std;


class TCalendario{
	private:
		int dia, mes, anyo;
		char* mensaje;
		bool todoOk( int dia, int mes, int anyo)const;
	public:
		TCalendario();
		TCalendario(int dia, int mes, int anyo, char *mens);
		TCalendario(const TCalendario &c);
		~TCalendario();
		TCalendario &operator=(const TCalendario &fecha);
		
		// Sobrecarga del operador: SUMA de fecha + un n�mero de dias;
		TCalendario operator+(int dias)const;
		// Sobrecarga del operador: RESTA de fecha - un n�mero de dias;
		TCalendario operator-(int dias)const;
		// Modifica la fecha increment�ndola en un dia (con postincremento);
		TCalendario operator++(int n);
		// Modifica la fecha increment�ndola en un dia (con preincremento);
		TCalendario &operator++();
		// Modifica la fecha decrement�ndola en un dia (con postdecremento);
		TCalendario operator--(int n);
		// Modifica la fecha decrement�ndola en un d�a (con predecremento);
		TCalendario &operator--();
		// Modifica la fecha
		bool ModFecha (int d, int m, int a);
		// Modifica el mensaje
		bool ModMensaje(char *mens);
		// Sobrecarga del operador igualdad;
		bool operator ==(const TCalendario &fecha) const;
		// Sobrecarga del operador desigualdad;
		bool operator !=(const TCalendario &fecha)const;
		// Sobrecarga del operador >; (ver ACLARACI�N sobre ORDENACI�N)
		bool operator>(const TCalendario &T2) const;
		// Sobrecarga del operador <; (ver ACLARACI�N sobre ORDENACI�N)
		bool operator<(const TCalendario &T2) const;



		//TCalendario vac�o
		bool EsVacio();
		// Devuelve el d�a del calendario;
		int Dia()const;
		// Devuelve el mes del calendario;
		int Mes()const;
		// Devuelve el a�o del calendario;
		int Anyo()const;
		// Devuelve el mensaje del calendario;
		char *Mensaje()const;
		
		
		// Sobrecarga del operador salida
		friend ostream & operator<<(ostream &cadena, const TCalendario &fecha);	
};
#endif