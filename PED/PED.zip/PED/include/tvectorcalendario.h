//adam roy frederick william, reading y2483358qs
#ifndef _TVCALENDARIO_
#define _TVCALENDARIO_
#include <iostream>
#include "tcalendario.h"
using namespace std;

class TVectorCalendario{
		
		//PARTE PRIVADA
	private:
		TCalendario *c;
		int tamano;
		TCalendario error;
	public:
		//FORMA CANÓNICA
		// Constructor por defecto
		TVectorCalendario();
		// Constructor a partir de un tamaño
		TVectorCalendario(int);
		// Constructor de copia
		TVectorCalendario(TVectorCalendario &);
		// Destructor
		~TVectorCalendario();
		// Sobrecarga del operador asignación
		TVectorCalendario & operator=(const TVectorCalendario &);
		
		//MÉTODOS
		// Sobrecarga del operador igualdad
		bool operator==(const TVectorCalendario &)const;
		// Sobrecarga del operador desigualdad
		bool operator!=(const TVectorCalendario &)const;
		// Sobrecarga del operador corchete (parte IZQUIERDA)
		TCalendario & operator[](int);
		// Sobrecarga del operador corchete (parte DERECHA)
		TCalendario operator[](int) const;
		// Tamaño del vector (posiciones TOTALES)
		int Tamano();
		// Cantidad de posiciones OCUPADAS (no vacías) en el vector
		int Ocupadas();
		// Devuelve TRUE si existe el calendario en el vector
		bool ExisteCal(TCalendario &);
		// Mostrar por pantalla mensajes de TCalendario en el vector, de fecha IGUAL O POSTERIOR a la pasada
		void MostrarMensajes(int,int,int);
		// REDIMENSIONAR el vectorde TCalendario
		bool Redimensionar(int);
		
		//FUNCIONES AMIGAS
		// Sobrecarga del operador salida
		friend ostream & operator<<(ostream &, const TVectorCalendario &);
};

#endif