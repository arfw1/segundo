//adam roy frederick william, reading y2483358q
#include <iostream>
#include "../include/tcalendario.h"
#include <string.h>
#include <stdio.h>
using namespace std;

TCalendario::TCalendario ()
{
	dia=1;
	mes=1;
	anyo=1900;
	mensaje=NULL;
}

TCalendario::TCalendario(int dia, int mes,int anyo, char *mens)
{

	if(todoOk(dia,mes,anyo)){
		this->dia=dia;
		this->mes=mes;
		this->anyo=anyo;
		this->mensaje=mens;
	}else{
		this->dia=1;
		this->mes=1;
		this->anyo=1900;
		this->mensaje=NULL;
	}
}

TCalendario::TCalendario ( const TCalendario &c)
{
	this->dia=c.dia;
	this->mes=c.mes;
	this->anyo=c.anyo;
	this->mensaje=c.mensaje;
}

TCalendario::~TCalendario()
 {
 	this->dia=1;
	this->mes=1;
	this->anyo=1900;
	this->mensaje=NULL;
}
TCalendario &TCalendario::operator=(const TCalendario &fecha)
{

	if(this!=&fecha){
		this->dia=fecha.dia;
		this->mes=fecha.mes;
		this->anyo=fecha.anyo;
		this->mensaje=fecha.mensaje;
	}
		
	return *this;
}

TCalendario TCalendario::operator+(int dias) const
{

	TCalendario fecha(*this);

	for(int i=1;i<=dias;i++){
		++fecha;
	}
	return fecha;
}

TCalendario TCalendario::operator-(int dias) const
{
	
	TCalendario fecha(*this);

	for(int i=1;i<=dias;i++){
		--fecha;
	}
	return fecha;
}
//post
TCalendario TCalendario::operator++(int n){

	TCalendario fecha(*this);
    ++(*this);
    return fecha;
}
//pre
TCalendario &TCalendario::operator++(){
	dia++;
	if((mes==4)||(mes==6)||(mes==9)||(mes==11)){
		if(dia>30){
			dia=1;
			mes++;
		}
	}else if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)){
		if(dia>31){
			dia=1;
			mes++;
		}
	}else if(mes==12){
		if(dia>31){
			dia=1;
			mes=1;
			anyo++;
		}
	}else if(mes==2){
		if(anyo%4==0 &&(anyo%100!=0 ||anyo%400==0 )){
			if(dia>29){
				dia=1;
				mes++;
			}
			
		}else{
			if(dia>28){
				dia=1;
				mes++;
			}
		}
	}
	return(*this);
}
//POST
TCalendario TCalendario::operator--(int n){
	TCalendario fecha(*this);
    --(*this);
    return fecha;

}
//PRE
TCalendario &TCalendario::operator--(){
	TCalendario fecha(*this);
	fecha.dia--;
	if((fecha.mes==4)||(fecha.mes==6)||(fecha.mes==9)||(fecha.mes==11)||(fecha.mes==8)){
		if(fecha.dia<1){
			fecha.dia=31;
			fecha.mes--;
		}
	}else if((fecha.mes==2)||(fecha.mes==4)||(fecha.mes==6)||(fecha.mes==8)||(fecha.mes==9)||(fecha.mes==11)){
		if(fecha.dia>1){
			fecha.dia=31;
			fecha.mes--;
		}
	}else if(fecha.mes==1){
		if(fecha.dia>1){
			fecha.dia=31;
			fecha.mes=12;
			fecha.anyo--;
		}
	}else if(fecha.mes==3){
		if(fecha.anyo%4==0 &&(fecha.anyo%100!=0 ||fecha.anyo%400==0 )){
			
			if(fecha.dia<1){
				fecha.dia=29;
				fecha.mes--;
			}
			
		}else{
			if(fecha.dia<1){
				fecha.dia=28;
				fecha.mes--;
			}
		}
	}
	if(todoOk(fecha.dia,fecha.mes, fecha.anyo)){
		this->dia=fecha.dia;
		this->mes=fecha.mes;
		this->anyo=fecha.anyo;
		this->mensaje=fecha.mensaje;
	}else{
		this->dia=1;
		this->mes=1;
		this->anyo=1900;
		this->mensaje=NULL;
	}
	return(*this);
}
bool TCalendario::ModFecha (int d, int m, int a)
{
	bool cambiado=false;
	if(todoOk(d,m,a)){
		this->dia=d;
		this->mes=m;
		this->anyo=a;
		cambiado=true;
	}
	return cambiado;
}

bool TCalendario::ModMensaje(char *mens){
	if(mens==NULL){
		this->mensaje=NULL;
		return false;
	}else{
		strcpy(this->mensaje, mens);
		return true;
	}
}

bool TCalendario::operator==(const TCalendario &fecha) const
{
	if((fecha.Dia()==this->dia)&&(fecha.Mes()==this->mes)&&(fecha.Anyo()==this->anyo)){
		if(strcmp(fecha.Mensaje(), this->mensaje)==0){
			return true;
		}
	}

	return false;
}

bool TCalendario::operator!=(const TCalendario &fecha) const
{
	if((fecha.Dia()!=this->dia)||(fecha.Mes()!=this->mes)||(fecha.Anyo()!=this->anyo)){
		if(strcmp(fecha.Mensaje(), this->mensaje)!=0){
			return false;
		}
	}

	return true;
}

bool TCalendario::operator>(const TCalendario &T2) const
{
	bool posterior=false;
	if(this->anyo > T2.Anyo()){
		posterior=true;
	}else if(this->anyo < T2.Anyo()){
		posterior=false;
	}else{
		if(this->mes > T2.Mes()){
			posterior=true;
		}else if(this->mes < T2.Mes()){
			posterior=false;
		}else{
			if(this->dia > T2.Dia()){
				if(T2.Mensaje()==NULL && this->mensaje==NULL){
					posterior=false;
				}else if(T2.Mensaje()==NULL &&this->mensaje!=NULL){
					posterior=true;
				}else if(T2.Mensaje()!=NULL &&this->mensaje==NULL){
					posterior=false;
				}else{
					if(strcmp(this->mensaje, T2.Mensaje())==0){
						posterior=false;
					}else{
						posterior=true;
					}
				}
			}else{
				posterior=false;
			}
		}
	}
	return posterior; 
}

bool TCalendario::operator<(const TCalendario &T2)const
{
	bool posterior=false;
	if(this->anyo > T2.Anyo()){
		posterior=false;
	}else if(this->anyo < T2.Anyo()){
		posterior=true;
	}else{
		if(this->mes > T2.Mes()){
			posterior=false;
		}else if(this->mes < T2.Mes()){
			posterior=true;
		}else{
			if(this->dia > T2.Dia()){
				posterior=false;
			}else if(this->dia > T2.Dia()){
				posterior=true;
			}else{
				if(T2.Mensaje()==NULL && this->mensaje==NULL){
					posterior=true;
				}else if(T2.Mensaje()==NULL &&this->mensaje!=NULL){
					posterior=false;
				}else if(T2.Mensaje()!=NULL &&this->mensaje==NULL){
					posterior=true;;
				}else{
					if(strcmp(this->mensaje, T2.Mensaje())==0){
						posterior=false;
					}else{
						posterior=true;
					}
				}
			}
		}
	}
	return posterior; 
}

bool TCalendario::EsVacio()
{
	if(this->dia==1 && this->mes==1 && this->anyo==1900 && this->mensaje==NULL){
		return true;
	}
	return false;
}

int TCalendario::Dia()  const{
	return this->dia;
}

int TCalendario::Mes() const{
	return this->mes;
}

int TCalendario::Anyo() const{
	return this->anyo;
}

char* TCalendario::Mensaje()const{
	return this->mensaje;
}
ostream &operator<<(ostream &cadena,const TCalendario &fecha)
{

	if(fecha.Dia()<10 &&fecha.Mes()>10){
		cadena<<"0"<<fecha.Dia()<<"/"<<fecha.Mes()<<"/"<<fecha.Anyo()<<" ";
	}else if(fecha.Dia()<10 && fecha.Mes()<10){
		cadena<<"0"<<fecha.Dia()<<"/0"<<fecha.Mes()<<"/"<<fecha.Anyo()<<" ";
	}else{
		cadena<<""<<fecha.Dia()<<"/"<<fecha.Mes()<<"/"<<fecha.Anyo()<<" ";
	}
	if(fecha.Mensaje()==NULL){
		cadena<<"\"\"";
	}else{
		cadena<<"\""<<fecha.Mensaje()<<"\"";
	}
	return cadena;
}

bool TCalendario::todoOk(int dia, int mes, int anyo) const
{
	bool ok=false;
	if(dia>0){
		if (anyo>=1900){
			if((mes==4)||(mes==6)||(mes==9)||(mes==11)){
				if((dia>0)&&(dia<=30)){
					ok=true;
				}else{
					ok=false;
				}
			}else if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)||(mes==12)){
				if((dia<=31) && (dia>=1) && (anyo>=1900)){
					ok=true;
				}else{
					ok=false;
				}
			}else if(mes!=2){
				ok=false;
			}

			if (anyo%4==0 &&(anyo%100!=0 ||anyo%400==0 )){
				if(mes==2){
					if (dia<=29&&dia>=1){
						ok=true;
					}else{
						ok=false;
					}
				}
			}else{
				if(mes==2){
					if (dia<=28&&dia>=1){
						ok=true;
					}else{
						ok=false;
					}
				}
			}
		}else{
			ok=false;
		}
	}else{
		ok=false;
	}
	
	
	return ok;
}

