//adam roy frederick william, reading y2483358q
#include <iostream>
#include "tlistacalendario.h"
#include "tvectorcalendario.h"
#include "tcalendario.h"
using namespace std;

TNodoCalendario::TNodoCalendario(){
	c=TCalendario();
	siguiente= NULL;
}

TNodoCalendario::TNodoCalendario (const TNodoCalendario &nodo)
{
	c=nodo.c;
	siguiente=nodo.siguiente;
}
		// Destructor
TNodoCalendario::~TNodoCalendario ()
{
	c=TCalendario();
	siguiente=NULL;
}
		// Sobrecarga del operador asignación
TNodoCalendario & TNodoCalendario::operator=(const TNodoCalendario &nodo)
{
	if(this!=&nodo){
		(*this).~TNodoCalendario();
		c=nodo.c;
		siguiente=nodo.siguiente;
	}
	return *this;
}


TListaPos::TListaPos()
{
	pos=NULL;
}
		
TListaPos::TListaPos(const TListaPos &lista){
	pos=lista.pos;
}
		// Destructor
TListaPos::~TListaPos(){
	pos=NULL;
}
		// Sobrecarga del operador asignación
TListaPos & TListaPos::operator=(const TListaPos &lista)
{
	if(this!=&lista){
		(*this).~TListaPos();
		pos=lista.pos;
	}
	return *this;
}
		// Sobrecarga del operador igualdad
bool TListaPos::operator==(const TListaPos &lista) const
{
	if(pos==lista.pos){
		return true;
	}
	return false;
}
		// Sobrecarga del operador desigualdad
bool TListaPos::operator!=(TListaPos &lista)
{
	if(pos==lista.pos){
		return false;
	}
	return true;
}
		// Devuelve la posición siguiente
TListaPos TListaPos::Siguiente() const
{
	TListaPos l;
	if(pos!=NULL){
		l.pos=this->pos->siguiente;
	}
	return l;
}
		// Posición vacía
bool TListaPos::EsVacia()const
{
	if(pos==NULL){
		return true;
	}
	return false;
}


TListaCalendario::TListaCalendario()
{
	primero=NULL;
}
		// Constructor de copia
TListaCalendario::TListaCalendario(const TListaCalendario &lista)
{
	*this=lista;
}
		//Destructor
TListaCalendario::~TListaCalendario(){
	primero=NULL;
}
		// Sobrecarga del operador asignación
TListaCalendario & TListaCalendario::operator=(const TListaCalendario &lista)
{
	if(this!= &lista){
		(*this).~TListaCalendario();
		primero=lista.primero;
	}
	return *this;
}
		// Sobrecarga del operador igualdad
bool TListaCalendario::operator==(const TListaCalendario &lista)const
{
	if(this==&lista){
		return true;
	}
	return false;
}
		//Sobrecarga del operador suma
TListaCalendario TListaCalendario::operator+ (const TListaCalendario &lista)const
{
	TListaCalendario list=*this;
	TNodoCalendario *nodo;
	nodo=list.primero;
	while(nodo!=NULL){
		list.Insertar(nodo->c);
		nodo=nodo->siguiente;
	}
	return list;
}
		//Sobrecarga del operador resta
TListaCalendario TListaCalendario::operator- (const TListaCalendario &lista)const
{
	TListaCalendario list=*this;
	TNodoCalendario *nodo;
	nodo=list.primero;
	while(nodo!=NULL){
		list.Borrar(nodo->c);
		nodo=nodo->siguiente;
	}
	return *this;
}
		// Inserta el elemento en la posición que le corresponda dentro de la lista
bool TListaCalendario::Insertar(const TCalendario &c){
    TNodoCalendario *nodo, *nodo1, *nodo2;
    bool mayor=false;
    bool insertar=false;
    nodo1 = NULL;
    nodo2 = primero;
    nodo = new TNodoCalendario();
    nodo->c=c;   

    while(nodo2 != NULL && !mayor){
        if(nodo2->c > c){
            mayor = true;
        }
        else if(nodo2->c == c){ 
                mayor = false;
        }else{
            nodo1 = nodo2;
            nodo2 = nodo2->siguiente;
        } 
    }
    if(nodo2 == NULL){
        mayor = true;
    }

    if(mayor){
        if(nodo2 == NULL && nodo1 != NULL){
            nodo->siguiente = nodo2;
            nodo1->siguiente = nodo;
        }
        else if(nodo1 == NULL){
            nodo->siguiente = nodo2;
            primero = nodo;
        }else if(nodo2 != NULL && nodo1 != NULL){
            nodo1->siguiente = nodo;
            nodo->siguiente = nodo2;
        }
        insertar = true;
    }
    return insertar;
}
		// Busca y borra el elemento
bool TListaCalendario::Borrar (const TCalendario &c){
    TNodoCalendario *nodo, *nodo1, *nodo2;
    bool mayor, borrar;
    mayor=borrar=false;
    nodo1 = NULL;
    nodo2 = primero;
    nodo = new TNodoCalendario();
    nodo->c=c;

    while(nodo2 && !mayor){
        if(nodo2->c > nodo->c){
            mayor = true;
        }
        else{
            if(nodo2->c == nodo->c){
                mayor = true;
            }
            else{
                nodo1 = nodo2;
                nodo2 = nodo2->siguiente;
            }
        }
    }

    if(mayor){
        if(nodo2->c == nodo->c){
            if(nodo2 == NULL){
                nodo1->siguiente = NULL;
            }
            else{
                if(nodo2 == primero){
                    primero = primero->siguiente;
                }else{
                    nodo1->siguiente = nodo2->siguiente;
                }
            }
            delete nodo2;
            nodo2 = NULL;
            borrar = true;
        }
    }
    return borrar;
}
		// Borra el elemento que ocupa la posición indicada
//bool TListaCalendario::Borrar (const TListaPos &){}
		//Borra todos los Calendarios con fecha ANTERIOR a la pasada.
//bool TListaCalendario::Borrar(int,int,int){}
		// Devuelve true si la lista está vacía, false en caso contrario
		
bool TListaCalendario::EsVacia()const
{
	if(primero==NULL){
		return true;
	}
	return false;
}
// Obtiene el elemento que ocupa la posición indicada
TCalendario TListaCalendario::Obtener(const TListaPos &lista)const
{	
	TCalendario cal;
	TNodoCalendario *nodo;
	
	nodo=primero;

	while(nodo!=NULL){
		if(nodo!=lista.pos){
			nodo=nodo->siguiente;
		}else{
			cal=nodo->c;
			break;
		}
	}
	
	return cal;
}
// Devuelve true si el Calendario está en la lista.
bool TListaCalendario::Buscar(const TCalendario &c)const
{
	  bool es = false;
    TNodoCalendario *nodo, *nodo1;
    nodo1 = new TNodoCalendario();
    nodo1->c=c;
    nodo = primero;

    while(nodo!=NULL && !es){
        if(nodo->c == c){
            es = true;
        }
        else{
            nodo=nodo->siguiente;
        }
    }
    return es;
}
// Devuelve la longitud de la lista
int TListaCalendario::Longitud()const
{
	int longitud=0;
	TNodoCalendario *nodo;
	nodo=primero;
	while(nodo!=NULL){
		nodo=nodo->siguiente;
		longitud++;
	}
	return longitud;
}
// Devuelve la primera posición en la lista
TListaPos TListaCalendario::Primera()const
{
	TListaPos p;
	p.pos=primero;
	return p;
}
// Devuelve la última posición en la lista
TListaPos TListaCalendario::Ultima()const
{
	TListaPos p;
	TNodoCalendario *nodo;
	nodo=primero;
	if(nodo!=NULL){
		while(nodo->siguiente!=NULL){
			nodo=nodo->siguiente;
		}
		p.pos=nodo;
	}
	return p;
}
// Suma de dos sublistas en una nueva lista
TListaCalendario TListaCalendario::SumarSubl (int I_L1, int F_L1, const TListaCalendario & L2, int I_L2,int F_L2)const
{
	TListaCalendario lista1(*this),lista2(L2),lista;
	return lista1.ExtraerRango(I_L1,F_L1)+lista2.ExtraerRango(I_L2,F_L2);
}
// Extraer un rango de nodos de la lista
TListaCalendario TListaCalendario::ExtraerRango (int n1, int n2)
{
	TListaCalendario lista;
	TNodoCalendario *nodo, *nodo1;
	nodo=primero;

	if(n1<1){
		n1=1;
	}
	for(int i=0;i<n1;i++){
		if(nodo!=NULL){
			nodo=nodo->siguiente;
		}else{
			break;
		}
	}

	for(int j=0;j<=n2;j++){
		if(nodo!=NULL){
			lista.Insertar(nodo->c);
			nodo1=nodo;
			nodo=nodo->siguiente;
			Borrar(nodo1->c);
		}else{
			break;
		}
		
	}

	return lista;
}
//Sobrecarga del operador salida
ostream & operator<<(ostream &cadena,const TListaCalendario &lista)
{
	TNodoCalendario *nodo;
	nodo=lista.primero;
	cadena<<"<";
	while(nodo!=NULL){
		if(nodo->siguiente==NULL){
			cadena<<nodo->c;
			nodo=nodo->siguiente;
		}else{
			cadena<<nodo->c<<" ";
			nodo=nodo->siguiente;

		}
	}
	cadena<<">";
	return cadena;
}