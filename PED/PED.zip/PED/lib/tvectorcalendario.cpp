//adam roy frederick william, reading y2483358q
#include <iostream>
#include "tvectorcalendario.h"
#include "tcalendario.h"
using namespace std;


TVectorCalendario::TVectorCalendario()
{
	tamano=0;
	c=new TCalendario[0];
	//error=new TCalendario();
	
}

TVectorCalendario::TVectorCalendario(int n)
{
	if(n<0){
		tamano=0;
		c=new TCalendario[0];
	}else{
		tamano=n;
		c=new TCalendario[n];
		//error=new TCalendario();

	}
	
}


TVectorCalendario::TVectorCalendario(TVectorCalendario &dates)
{
	this->tamano=0;
	this->c=NULL;

	if(dates.tamano<0){
		tamano=0;
	}else{
		tamano=dates.tamano;
	}
	c=new TCalendario[tamano];

	
}
TVectorCalendario::~TVectorCalendario()
{
	delete[] c;
	tamano=0;
	c=NULL;
	//error=new TCalendario();
	
}

TVectorCalendario &TVectorCalendario::operator=(const TVectorCalendario &dates)
{
	if(this!=&dates){

		(*this).~TVectorCalendario();

		this->tamano=dates.tamano;

		if (tamano==0){
			this->c=NULL;
		}else{
			this->c=new TCalendario[tamano];
		}
		for(int i=0;i<tamano;i++){
			c[i]=dates.c[i];
		}
	}
	return *this;
}
		

bool TVectorCalendario::operator==(const TVectorCalendario &dates) const{
	bool iguales;
	int i=tamano;
	if(dates.tamano!=this->tamano){
		iguales=false; 
	}else{
		while(i>0){
			if(dates.c[i]!=this->c[i]){
				iguales=false;
				i=0;
			}else{
				i--;
				iguales=true;
			}
		}
	}
	return iguales;
}

bool TVectorCalendario::operator!=(const TVectorCalendario &dates)const{
bool distintos=false;
	int i=tamano;
	if(dates.tamano!=this->tamano){
		distintos=true;
	}else{
		while(i>0){
			if(dates.c[i]!=this->c[i]){
				distintos=true;
				i=0;
			}else{
				i--;
				distintos=false;
			}
		}

	}
	return distintos;
}

TCalendario &TVectorCalendario::operator[](int n){
	if(n>=1 && n<= tamano){
		return c[n-1];
	}else{
		return error;
	}
}
//derecha
TCalendario TVectorCalendario::operator[](int n) const{
	if(n>=1 && n<= tamano){
		return c[n-1];
	}else{
		TCalendario *cal= new TCalendario() ;
		return *cal;
	}
}

int TVectorCalendario::Tamano(){
	return tamano;
}

int TVectorCalendario::Ocupadas()
{
	int ocupadas=0;
	for(int i=0;i<tamano;i++){
		if(c[i].EsVacio()==false){
			ocupadas++;
		}
	}
	return ocupadas;
}

bool TVectorCalendario::ExisteCal(TCalendario &fecha)
{
	bool existe=false;
	for(int i=0;i<tamano;i++){
		if(c[i]==fecha){
			existe=true;
		}
	}
	return existe;
}
		
void TVectorCalendario::MostrarMensajes(int d,int m,int a){
	TVectorCalendario imprimir;
	for(int i=0;i<tamano;i++){
		if(c[i]==TCalendario(d,m,a,NULL) || c[i]>TCalendario(d,m,a,NULL)){
			imprimir.c[i]=c[i];
		}
	}
	if(imprimir.tamano==0){
			cout<<"[]"<<endl;
	}else{
		for(int j=0;j<imprimir.tamano;j++){

			if(j==0){
				cout<<"[";
			}else{
				if(j+1!=imprimir.tamano){
					cout<<imprimir[j]<<",";
				}else{
					cout<<imprimir[j]<<"]";
				}
			}
		}
	}
	
}
		
bool TVectorCalendario::Redimensionar(int n)
{	bool redimensionado=false;
	TCalendario *redi= new TCalendario[n];
	if(n>0 && n>tamano){
		for(int i=0;i<n;i++){
			if(i>=this->tamano){
				//TCalendario cal;
				redi[i]=TCalendario();
			}else{
				redi[i]=c[i];
			}
		}
		redimensionado=true;
	}else if(n>0 && n<tamano){
		for(int i=0;i<n;i++){
			redi[i]=c[i];
		}
		redimensionado=true;
	}
	delete[] c;
	this->c=redi;
	this->tamano=n;
	return redimensionado;
}
		
		//FUNCIONES AMIGAS
		// Sobrecarga del operador salida
ostream & operator<<(ostream &cadena, const TVectorCalendario &fechas)
{
	if(fechas.tamano==0){
		cadena<<"[]";
	}else{
		cadena<< "[";
		for(int i=1;i<=fechas.tamano;i++){
			if(i==1){
				cadena<<"("<<i<<") ";
			}else{
				cadena<<" ("<<i<<") ";
			}
			if(i!=fechas.tamano){
				cadena<<fechas[i]<<",";
			}else{
				cadena<<fechas[i]<<"]";
			}
		}
	}
	return cadena;
}
