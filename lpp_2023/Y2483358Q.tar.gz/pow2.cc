//Adam Roy Frederick William Reading Y2483358Q
#include <iostream>
#include <cmath>
using namespace std;

unsigned long pasos2_1 , pasos2_2, pasos2_3,pasos2_4;
//lineal exponencial y logarítmica
//Omicron (n)
unsigned long pow2_1(unsigned n){
    pasos2_1++;
    if (n == 0){
        return 1;
    }else{
        return 2 * pow2_1(n-1);
    }
}
//Theta (2^n)
unsigned long pow2_2(unsigned n){
    pasos2_2++;
    if (n == 0){
        return 1;
    }else{
        return pow2_2(n-1) + pow2_2(n -1);
    }
}

//Omicron(log n)
unsigned long pow2_3(unsigned n){
    pasos2_3++;
    if (n == 0){
        return 1;
    }else{
        if(n%2==0){
            return  pow2_3(n/2)*pow2_3(n/2);
        }else{
            return 2*pow2_3(n/2)*pow2_3(n/2);
        }
    }
}

int main(){
    int esperado,res1,res2,res3 = 0;
    cout<< "#==============================================================="<<endl;
    cout<<"#\tn\tpow2_1\tpow2_2\t\tpow2_3"<<endl;
    cout<< "#==============================================================="<<endl;
    for (unsigned long n = 0;n<=20;n++){
        pasos2_1=0;
        pasos2_2=0;
        pasos2_3=0;

        esperado=pow(2,n);
        res1= pow2_1(n);
        res2=pow2_2(n);
        res3=pow2_3(n);
        
        cout<<"\t"<<n<<"\t"<<pasos2_1<<"\t"<<pasos2_2<<"\t"<<"\t"<<pasos2_3<<endl;
        
        if ( esperado!=res1||esperado!=res2||esperado!=res3){
            throw "Error de cálculo";
        }
    }
    
    
    return 0;

}
