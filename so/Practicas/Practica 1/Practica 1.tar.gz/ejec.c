#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

void alarma(){
	//tiene que ejecutar una funcion exec
	//hay que crear un hijo porque si no se carga a z
	if(fork()==0){
		execlp("pstree","pstree",NULL);
	}
}
//OTRA OPCION
/* void ejecuta_pstree(){
	system(pstree);
}*/
int main (int argc, char * argv[]){
	int t=atoi(argv[1]),i,j,pidArb,pidA,pidB,pidX,pidY,pidZ;
	//kill(a quien (PID),tipo de señal (sigalarm...)
	printf("\nSoy el proceso ejec: mi pid es %d",getpid());
	pidArb=getpid();	
	for(i=0;i<3;i++){
		if(fork()>0){
			if(i==0){
				printf("\nSoy el proceso A: mi pid es %d. Mi padre es %d",getpid(),pidArb);
				pidA=getpid();
			}else if(i==1){
				printf("\nSoy el proceso B: mi pid es %d. Mi padre es %d. Mi abuelo es %d",getpid(),pidA,pidArb);
				pidB=getpid();
			}else if(i==2){
				printf("\nSoy el proceso X: mi pid es %d. Mi padre es %d. Mi abuelo es %d.Mi bisabuelo es %d",getpid(),pidB,pidA,pidArb);
				pidX=getpid();
			}
			
			break;
		}
	}
	if(i==2){
		for(j=0;j<2;j++){
			if(fork()==0){
				if(j==0){
					printf("\nSoy el proceso Y: mi pid es %d. Mi padre es %d. Mi abuelo es %d.Mi bisabuelo es %d",getpid(),pidB,pidA,pidArb);
					pidY=getpid();
				}else if(j==1){
					printf("\nSoy el proceso Z: mi pid es %d. Mi padre es %d. Mi abuelo es %d.Mi bisabuelo es %d",getpid(),pidB,pidA,pidArb);
					pidZ=getpid();
				}
				break;
			}
		}
	}
	signal(SIGALRM,alarma);
	alarm(t); //Se envia a si mismo una señal de alarma en 3s y ejecuta alarma
	pause();
	printf("Soy Z (%d) y muero\n",pidZ);
	kill(pidZ, SIGKILL);
	printf("Soy Y (%d) y muero\n",pidY);
	kill(pidY, SIGKILL);
	printf("Soy X (%d) y muero\n",pidX);
	kill(pidX, SIGKILL);
	printf("Soy B (%d) y muero\n",pidB);
	kill(pidB, SIGKILL);
	printf("Soy A (%d) y muero\n",pidA);
	kill(pidA, SIGKILL);
	printf("Soy ejec (%d) y muero\n",pidArb);
	kill(pidArb, SIGKILL);
}
