#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#define tam_buffer 10
 
int main(int argc, char *argv[]) {
     
    int escrib[2];
     
    int tub;
    char bffr[tam_buffer];
     
    char m1[40], m2[5];
    sprintf(m1, "%s", argv[1]);
    strcat(m1, ".h00");
     
    if (argc == 3){
         
        int tamPart = atoi(argv[2]);
        int partida = open(argv[1], O_RDONLY);
        int parte, cerrar = 0, cont = 0, suma = 0;
        int leido = 1, escrito = 0;
        int tam; 
        pid_t pid;
         
        while (leido > 0) {
            tub = pipe(escrib);
            pid = fork();
             
            if (pid != 0) {
                close(escrib[0]);
                 
                while (suma < tamPart && cerrar == 0) {
                     
                    if ((tamPart - suma) > tam_buffer) {
                        tam = tam_buffer;
                    }
                    else {
                        tam = (tamPart - suma);
                    }
                     
                    leido = read(partida, bffr, tam);
                     
                    if (leido == 0) {
                        cerrar = 1;
                    }
                    else {
                        suma += leido;
                        write(escrib[1], bffr, leido);
                    }
                     
                }
                 
                close(escrib[1]);
                wait(); //Esperamos a que el hijo escriba en el nuevo fichero
                suma = 0;
                cont++;
                 
                sprintf(m1, "%s", argv[1]);
                if (cont < 10) {
                    sprintf(m2, ".h0%d", cont);
                }
                else {
                    sprintf(m2, ".h%d", cont);
                }
                 
                strcat(m1, m2);
            }
                 
            else {
                       
                close(escrib[1]);
                parte = open(m1, O_CREAT | O_WRONLY | O_APPEND, 0777)
                       
                while (suma < tamPart && cerrar == 0) {
                     
                    if ((tamPart - suma) > tam_buffer) {
                        tam = tam_buffer;
                    }
                    else {
                        tam = tamPart - suma;
                    }
                     
                    leido = read(escrib[0], bffr, tam);
                     
                    if (leido == 0) {
                        cerrar = 1;
                    }
                    else {
                        suma += leido;
                        escrito = write(parte, bffr, leido);
                    }
                     
                }
                close(parte);
                exit(0);
            }
             
        }
        close(partida);
    }
     
}