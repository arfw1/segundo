#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

int main (int argc, char * argv[]){
	int pids[atoi(argv[1])][atoi(argv[2])];
	int i;
	int j;
	for (i = 0; i < atoi(argv[1]); ++i)
	{
		if(fork()>0){
			pids[i][0]=getpid();
			break;
		}
	}
	if(i==atoi(argv[1]))
		for(j=0;j<atoi(argv[2]);j++){
			if(fork()==0){
				pids[i][j]=getpid();
				printf("Soy el subhijo %d, mi padres son:",getpid());
				for(int k=0;k<i;k++){
					printf(",%d",pids[k][0]);
				}
				break;
			}
		}
	printf("Soy el superpadre %d, mis hijos son:",getpid());
	for(int k=0;k<i;k++){
		for(int l=0;l<j;l++){
			printf(",%d",pids[l][k]);
		}
	}
}
