package clases;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Gestormemoria 
{
	private int numProcesos;
	private int tamanoMemoria;
	private String fentrada;
	private String fsalida;
	private ArrayList <Proceso> procesos;//lista de procesos
	private ArrayList <Memoria> memoria;
	private int instante;
	public PrintStream ps;
	public Scanner sc;
	
	public Gestormemoria()//constructor por defecto
	{
		numProcesos = 0;
		tamanoMemoria = 0;
		fentrada = new String("");
		fsalida = new String("");
		instante = 0;
		memoria=new ArrayList<Memoria>();
		procesos=new ArrayList<Proceso>();
	}
	public Gestormemoria(int tamanoMemoria,String fentrada, String fsalida) throws FileNotFoundException//constructor sobrecargado
	{
		numProcesos = 0;
		instante = 0;
		this.tamanoMemoria=tamanoMemoria;
		this.fentrada = fentrada;
		this.fsalida = fsalida;
		ps = new PrintStream(fsalida);
		File f = new File(this.fentrada);
		sc = new Scanner(f);
		memoria=new ArrayList<Memoria>();
		procesos=new ArrayList<Proceso>();
		

		for(int x=0; x<=tamanoMemoria; x++)
		{
			Memoria m = new Memoria();//crea los huecos
			m.libre = true;
			m.ocupante = "hueco";
			memoria.add(m);
		}
		
		Leer();
	}
	public void Leer() throws FileNotFoundException
	{
		
		while(sc.hasNext())//crea un proceso por cada linea y lo añado a la lista de proceso
		{		
			Proceso p = new Proceso();
			p.Leer(sc);//linea k leo
			addProceso(p);
		}
		
		numProcesos=procesos.size();
	}
	
	public void addProceso(Proceso p)
	{
		if(p != null)
		{
			procesos.add(p);//se añade si no esta vacio
		}
	}
	public void Exportar() throws FileNotFoundException
	{
		String actual = new String("");
		int inicio=0;

		ps.print(instante + " ");
		
		for(int t=0; t<=tamanoMemoria; t++)
		{
			// Controlo el final del proceso
			if(!memoria.get(t).ocupante.equals(actual) && t!=0)
			{
				ps.print("[" + inicio + " " + actual + " " + (t-inicio) + "] ");
				inicio=t;
			}
			
			// Controlo el final de la memoria
			if(memoria.get(t).ocupante.equals(actual) && t==tamanoMemoria)
			{
				ps.print("[" + inicio + " " + actual + " ");
				if(t-inicio == 0)
					ps.print(t + "]");
				else
					ps.print(t-inicio + "]");
			}
			actual = memoria.get(t).ocupante;
		}
		ps.println();
	}
	public void Primer() throws FileNotFoundException
	{
		boolean terminado=false;
		boolean hecho;

		while(!terminado)
		{
			hecho=false;
			
			for(int t=0; t<numProcesos && t<20; t++)
			{
				if(instante >= procesos.get(t).tiempoEntrada && !procesos.get(t).enEjecucion && procesos.get(t).duracion!=-1)
				{
					int inicio=0;
					boolean encontrado=false;
					
					for(int y=0; y<=tamanoMemoria && !hecho; y++)
					{
						// Encontramos el inicio de la introduccion en memoria
						if(memoria.get(y).libre && !encontrado)
						{
							inicio=y;
							encontrado=true;
						}

						// Si la posicion esta ocupada y hemos encontrado el inicio, ese no es el inicio (falta espacio)
						if(!memoria.get(y).libre && encontrado)
							encontrado=false;

						// Si tenemos inicio y el espacio es el que necesitamos
						if(encontrado && (y-inicio)==procesos.get(t).memoria)
						{
							hecho=true;
							procesos.get(t).enEjecucion=true; 
							
							for(int z=inicio; z<(inicio+procesos.get(t).memoria); z++)
							{
								memoria.get(z).libre=false;
								memoria.get(z).ocupante = procesos.get(t).nombre;
							}
							
						} 
						
					}				
				}
			}

			// Decrementamos en una unidad los procesos que esten en ejecucion
			for(int t=0; t<numProcesos && t<20; t++)
			{
				if(procesos.get(t).enEjecucion && procesos.get(t).duracion!=-1)
					procesos.get(t).duracion = procesos.get(t).duracion-1;

				if(procesos.get(t).duracion==-1 && procesos.get(t).enEjecucion)
				{
					// Quitamos el proceso de ejecucion
					procesos.get(t).enEjecucion=false;

					// Liberamos la memoria
					for(int aux=0; aux<=tamanoMemoria; aux++)
					{
						if((memoria.get(aux).ocupante).equals(procesos.get(t).nombre))
						{
							memoria.get(aux).libre=true;
							memoria.get(aux).ocupante= "hueco";
						}
					}
				}
			}
			// Comprobamos que todos los procesos hayan terminado
			terminado=true;
			for(int t=0; t<numProcesos && t<20; t++)
				if(procesos.get(t).duracion!=-1)
					terminado=false;

			Exportar();
			
			// Incrementamos el intanste de tiempo
			instante++;
		}
	}
	public void Mejor() throws FileNotFoundException
	{
		int num;
		boolean terminado=false;
		boolean hecho;
		int[] particion = new int[30];
		int numParticiones;
		for(int i = 0; i < 30;i ++)
			particion[i] = -1;

		while(!terminado)
		{
			hecho=false;
			
			for(int t=0; t<numProcesos && t<20; t++)
			{
				numParticiones=0;
				num=0;
				if(instante >= procesos.get(t).tiempoEntrada && !procesos.get(t).enEjecucion && procesos.get(t).duracion!=-1)
				{
					int inicio=0;
					boolean encontrado=false;
					
					for(int y=0; y<=tamanoMemoria && !hecho; y++)
					{
						// Encontramos el inicio de la introduccion en memoria
						if(memoria.get(y).libre && !encontrado)
						{
							inicio=y;
							encontrado=true;
						}

						// Si la posicion esta ocupada y hemos encontrado el inicio, ese no es el inicio (falta espacio)
						if(!memoria.get(y).libre && encontrado)
							encontrado=false;

						// Si tenemos inicio y el espacio es el que necesitamos
						if((encontrado && (y-inicio)>=procesos.get(t).memoria && memoria.get(y).ocupante.equals(memoria.get(y-1).ocupante)==false) || y==tamanoMemoria)
						{
							particion[numParticiones]=y-inicio;
							numParticiones++;
						} 
						
					}			

					// Buscamos la particion mas pequeña en la que nos quepa
					for(int c=1; numParticiones>0 && c<numParticiones; c++)
					{
						if(particion[num] > particion[c])
							num=c;
					}

					hecho=false;
					inicio=0;
					// Ahora buscamos la particion nº num, que es donde introduciremos el proceso
					for(int x=0; x<=tamanoMemoria && !hecho; x++)
					{
						int part=0;
						// Encontramos el inicio de la introduccion en memoria
						if(memoria.get(x).libre && !encontrado)
						{
							inicio=x;
							encontrado=true;
						}

						// Si la posicion esta ocupada y hemos encontrado el inicio, ese no es el inicio (falta espacio)
						if(!memoria.get(x).libre && encontrado)
							encontrado=false;

						// Si tenemos inicio y el espacio es el que necesitamos
						if((encontrado && (x-inicio)>=procesos.get(t).memoria && memoria.get(x).ocupante.equals(memoria.get(x-1).ocupante)==false) || x==tamanoMemoria)
						{
							
							// Es la particion que buscamos, con lo cual, metemos el proceso
							if(num == part)
							{
								if(inicio==2048)
									inicio=0;
							
								hecho=true;
								procesos.get(t).enEjecucion=true; 
							
								for(int z=inicio; z<(inicio+procesos.get(t).memoria) && z < tamanoMemoria; z++)
								{	
									memoria.get(z).libre=false;
									memoria.get(z).ocupante = procesos.get(t).nombre;
								}
							}
							else
								part++;
							
						} 
					}
					
				}
			}

			// Decrementamos en una unidad los procesos que esten en ejecucion
			for(int t=0; t<numProcesos && t<20; t++)
			{
				if(procesos.get(t).enEjecucion && procesos.get(t).duracion!=-1)
					procesos.get(t).duracion = procesos.get(t).duracion - 1;

				if(procesos.get(t).duracion==-1 && procesos.get(t).enEjecucion)
				{
					// Quitamos el proceso de ejecucion
					procesos.get(t).enEjecucion=false;

					// Liberamos la memoria
					for(int aux=0; aux<=tamanoMemoria; aux++)
					{
						if(memoria.get(aux).ocupante.equals(procesos.get(t).nombre))
						{
							memoria.get(aux).libre = true;
							memoria.get(aux).ocupante = "hueco";
						}
					}
				}
			}
			// Comprobamos que todos los procesos hayan terminado
			terminado=true;
			for(int t=0; t<numProcesos && t<20; t++)
				if(procesos.get(t).duracion!=-1)
					terminado=false;

			Exportar();
			
			// Incrementamos el intanste de tiempo
			instante++;
		}
	}
}

