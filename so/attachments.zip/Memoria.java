package clases;

public class Memoria 
{
	public boolean libre;
	public String ocupante;
	
	public Memoria()
	{
		libre = true;
		ocupante = new String("");
	}
}
