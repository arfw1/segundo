package clases;

import java.util.Scanner;

public class Proceso 
{
	public int tiempoEntrada;
	public int duracion;
	public int memoria;
	public String nombre;
	public boolean terminado;
	public boolean enEjecucion;
	
	public Proceso()
	{
		tiempoEntrada = 0;
		duracion = 0;
		memoria = 0;
		nombre = new String("");
		terminado = false;
		enEjecucion = false;
	}
	public void Leer(Scanner sc)
	{
		memoria=sc.nextInt();
		duracion=sc.nextInt();
		nombre = sc.next();
		tiempoEntrada=0;
		terminado=false;
		enEjecucion=false;
	}
}
