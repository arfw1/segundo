package mains;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import clases.Gestormemoria;

public class main1 
{
	public static void main(String[] args)
	{
		int algoritmo = 0;
		
		System.out.println("---------------Algoritmo------------------");
		System.out.println("1. Primer Hueco");
		System.out.println("2. Mejor Hueco");
		System.out.print("Opcion: ");
		
		//leemos la opcion
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader (isr);
		try { //control de excepciones
			String texto = br.readLine();
			algoritmo = Integer.parseInt(texto);
		} catch (IOException e1) {//si hay algun error se ejecuta y acaba el programa
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} //terminamos de leer la opcion
		
		int tam = Integer.parseInt(args[0]);
		String entrada = new String(args[1]);
		String salida = new String(args[2]);
	
		if (algoritmo == 1)
		{
			try 
			{
				Gestormemoria gestor = new Gestormemoria(tam,entrada,salida);
				gestor.Primer();
				gestor.ps.close();
				gestor.sc.close();
			} catch (FileNotFoundException e) 
			{
				System.err.println("No se ha encontrado el fichero de entrada especificado");
			}
			
		}
		else if(algoritmo == 2)
		{
			try 
			{
				Gestormemoria gestor = new Gestormemoria(tam,entrada,salida);
				gestor.Mejor();
				gestor.ps.close();
				gestor.sc.close();
			} catch (FileNotFoundException e) 
			{
				System.err.println("No se ha encontrado el fichero de salida especificado");
			}
		}			
		else
		{
			System.out.println("ERROR, ALGORITMO INEXISTENTE");
		}
	}
}
